'''
Created on 2018. 3. 24.

@author: admin
'''
from django.conf.urls import url
from django.contrib.auth.views import login, logout
from . import views # from user import views
app_name = 'user'   # {% url 'user:sign' %} 
urlpatterns=[
    url(r'^sign/$', views.sign ,name='sign'), # 회원가입
    #127.0.0.1:8000/user/login
    url(r'^login/$', login ,name='login'), #로그인 registration/login.html
    url(r'^logout/$', logout ,name='logout'), # 로그아웃 
]