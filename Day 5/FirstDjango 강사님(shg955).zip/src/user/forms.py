'''
Created on 2018. 3. 24.

@author: admin
'''
from django.forms.models import ModelForm
from django.contrib.auth.models import User

class signForm(ModelForm):
    class Meta:
        model = User
        fields=['username', 'password', 'email']
        