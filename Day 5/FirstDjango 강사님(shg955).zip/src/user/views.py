from django.shortcuts import render
from django.contrib.auth.models import User # 장고에서 만든 User 모델 클래스
from . import forms
from django.http.response import HttpResponseRedirect
from django.urls import reverse

def sign(request):
    if request.method == "POST": #post으로 접근
        form = forms.signForm(request.POST) #사용자 입력을 signForm에 입력
        if form.is_valid():
            new_user = User.objects.create_user(**form.cleaned_data) #새로운 유저 생성
            return HttpResponseRedirect( reverse("user:login" ) )
    else: #get으로 접근
        form = forms.signForm()
    
    return render(request, 'registration/sign.html' , {'form' : form})