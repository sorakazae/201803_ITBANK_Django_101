'''
Created on 2018. 3. 21.

@author: USER
'''
from django.forms.models import ModelForm
from django.contrib.auth.models import User 
from django import forms
    
class signForm(ModelForm):
    class Meta:
        password = forms.CharField(widget=forms.PasswordInput)
        model = User
        widgets = {
            'password': forms.PasswordInput(),
        }
        fields=['username', 'email','password']
    def __init__(self, *args, **kwargs):
        super(signForm,self).__init__(*args,**kwargs)
        self.fields['password'].widget.attrs['type']="password"
        self.fields['email'].widget.required=False
        
class loginForm(ModelForm):
    class Meta:
        password = forms.CharField(widget=forms.PasswordInput)
        model = User
        widgets = {
            'password': forms.PasswordInput(),
        }
        fields=['username','password']