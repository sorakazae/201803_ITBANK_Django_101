'''
Created on 2018. 3. 21.

@author: USER
'''
from django.conf.urls import url
from . import views

#app_name = 'users'
urlpatterns=[
    url(r'^sign/$',views.sign,name='sign'),
    #url(r'^login/$',views.ulogin,name='login'), 
    #url(r'^logout/$',views.ulogout,name='logout'),
]