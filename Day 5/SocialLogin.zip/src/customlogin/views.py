from django.shortcuts import render
from django.shortcuts import render
from .forms import signForm, loginForm 
from django.contrib.auth.models import User
from django.contrib.auth import login,logout, authenticate
from django.http.response import HttpResponseRedirect
from django.urls import reverse
# Create your views here.


def home(request):
    return render(request, 'home.html')



def sign(request):
    if request.method == "POST":
        form = signForm(request.POST)
        if form.is_valid():
            new_user = User.objects.create_user(**form.cleaned_data)
            return HttpResponseRedirect(reverse('home'))
    else:
        form = signForm()
        
    return render(request,'customlogin/sign.html',{'form' : form})

def ulogin(request):
    if request.method == "POST":
        
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        print(user)
        if user is not None:
            login(request, user)
            return HttpResponseRedirect(reverse('polls:index'))
        else:
            form = loginForm(request.POST)
            error_log = '로그인 실패. 입력 정보를 확인하세요'
            return render(request,'customlogin/login.html',{'form' : form,'error_log':error_log})
    else:
        form = loginForm()
        
    return render(request,'customlogin/login.html',{'form' : form})
def ulogout(request):
    logout(request)
    return HttpResponseRedirect(reverse('polls:index'))