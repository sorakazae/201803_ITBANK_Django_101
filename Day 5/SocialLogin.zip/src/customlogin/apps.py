from django.apps import AppConfig


class CustomloginConfig(AppConfig):
    name = 'customlogin'
