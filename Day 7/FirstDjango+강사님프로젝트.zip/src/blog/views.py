from django.shortcuts import render
from .models import Post,Posttype,Image
# Create your views here.
from django.views.generic.list import ListView
from django.views.generic.detail import DetailView
from django.views.generic.edit import CreateView, UpdateView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.http.response import HttpResponseRedirect
from django.urls.base import reverse_lazy
from django.urls import reverse
'''
def index(request):
    obj = Post.objects.all()[:10]
    return render(request,'blog/templates/index.html', {'post' : obj })
'''

class index(ListView):
    template_name ='blog/templates/index.html' #매칭할 탬플릿 경로
    model = Post   #사용할 모델 클래스 설정
    paginate_by = 2 #한페이지에 몇개의 객체를 보여줄 것인지 설정
    context_object_name = 'post' #탬플릿에 모델 객체들을 넘겨줄때 사용할 변수 이름
    
class detail(DetailView):
    template_name = 'blog/templates/detail.html'
    model = Post
    context_object_name = 'post'
    
class posting(LoginRequiredMixin ,CreateView):
    model = Post
    fields=['type','headline','content',]
    #success_url = reverse_lazy('blog:index')
    template_name = 'blog/templates/posting.html'
    def form_valid(self, form):
        obj = form.save(commit=False)
        obj.author = self.request.user
        obj.save()
        for f in self.request.FILES.getlist('files'):
            image = Image(post=obj,image=f)
            image.save()
        return HttpResponseRedirect( reverse('blog:detail', args=(obj.id,)  )  )
    
#from django.views.generic.edit import UpdateView
class updatePosting(LoginRequiredMixin,UpdateView):
    model = Post
    fields=['type','headline','content']
    template_name = 'blog/templates/updatePosting.html'
    success_url = reverse_lazy('blog:index')
    
    
    
    
    
    
    
    
    
    
    