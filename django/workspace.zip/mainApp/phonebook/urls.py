from django.conf.urls import include, url
from phonebook import views
urlpatterns = [
    url(r'^$', views.test),
    url(r'^index/', views.index,name='index'),
    url(r'^add/', views.add,name='add'),
    url(r'^delete/([0-9]+)/', views.delete,name='delete'),
    url(r'^detail/([0-9]+)/', views.detail,name='detail'),
    url(r'^update/([0-9]+)/', views.update,name='update'),
]
