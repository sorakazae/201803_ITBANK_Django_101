# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='PhoneBook',
            fields=[
                ('id', models.AutoField(serialize=False, auto_created=True, primary_key=True, verbose_name='ID')),
                ('이름', models.CharField(max_length=50)),
                ('전화번호', models.CharField(max_length=15)),
                ('이메일', models.EmailField(max_length=254)),
                ('주소', models.CharField(max_length=100)),
                ('생년월일', models.DateField()),
            ],
        ),
    ]
