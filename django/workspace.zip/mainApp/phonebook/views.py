from django.shortcuts import render,redirect
from phonebook.models import PhoneBook
def test(request):
    return render(request,'phonebook/test.html')
def index(request):
    alluser = PhoneBook.objects.values('id','이름','전화번호')
    print(alluser)
    context = {'phonebook':alluser}
    return render(request,'phonebook/index.html',context)
def add(request):
    if request.user.is_active != True:
        return redirect('login')
    if request.method == 'POST':
        phonebook_Table = PhoneBook()
        phonebook_Table.이름 = request.POST.get('name')
        phonebook_Table.전화번호 = request.POST.get('phNum')
        phonebook_Table.이메일 = request.POST.get('email')
        phonebook_Table.주소 = request.POST.get('addr')
        phonebook_Table.생년월일 = request.POST.get('bir')
        phonebook_Table.작성자 = request.user.username
        phonebook_Table.save()
        return redirect("PB:index")
    else:
        return render(request,'phonebook/add.html')
def update(request,userId):
    if request.user.is_active != True:
        return redirect('login')
    table = PhoneBook.objects.get(id=userId)
    context={"phonebook":table}
    if request.method == 'POST':
        table.이름 = request.POST.get('name')
        table.전화번호 = request.POST.get('phNum')
        table.이메일 = request.POST.get('email')
        table.주소 = request.POST.get('addr')
        table.생년월일 = request.POST.get('bir')
        table.save()
        return redirect('PB:index')
    else:
        if table.작성자 == request.user.username:
            return render(request,'phonebook/update.html',context)
        else:
            return redirect('PB:index')
        
def delete(request,delId):
    phone = PhoneBook.objects.get(id=delId)
    phone.delete()
    return redirect('PB:index')
    
    #return render(request,'phonebook/delete.html')
def detail(request,userId):
    userInfo = PhoneBook.objects.values('id',
    '이름','전화번호','이메일','주소','생년월일','작성자').get(id=userId)
    context={'phonebook':userInfo}
    return render(request,'phonebook/detail.html',context)

















