from django.conf.urls import include, url
from border import views
urlpatterns = [
    url(r'^([0-9]+)/$', views.index,name='index'),
    url(r'^add/', views.add,name='add'),
    url(r'^detail/([0-9]+)/', views.detail,name='detail'),
    url(r'^delete/([0-9]+)/', views.delete,name='delete'),
    url(r'^update/([0-9]+)/', views.update,name='update'),
    url(r'^page/([0-9]+)/', views.page,name='page'),
]



















