from django.shortcuts import render,redirect
from border.models import Border
from datetime import datetime
from django.core.paginator import Paginator

# Create your views here.
def page(request,page):
    border = Border.objects.all()
    print('type : ',type(border))
    print('len : ',len(border))
    print('border : ',(border))
    
    paging = Paginator(border,2)
    
    context={'border':paging.page(page)}
    return render(request,'border/page.html',context)


def update(request,userId):
    border = Border.objects.get(id=userId)
    context = {'border':border}
    if request.method=='POST':
        border.제목 = request.POST.get('title')
        border.내용 = request.POST.get('context')
        border.수정일 = datetime.now()
        border.save()
        return redirect('BD:detail',border.id)
    else:
        return render(request,'border/update.html',context)
def delete(request, userId):
    dele = Border.objects.get(id=userId)
    dele.delete()
    return redirect('BD:index')
def detail(request,userId):
    cnt = Border.objects.get(id=userId)
    cnt.조회수 = cnt.조회수 + 1
    cnt.save()
    
    userAll = Border.objects.values('id',
        '제목','작성자','내용','조회수','작성일','수정일').get(id=userId)
    userAll['내용'] = userAll['내용'].replace('\n','<br>')
    print('userAll : ',userAll)
    context={'border':userAll}
    return render(request,'border/detail.html',context)
def index(request,page):
    border = Border.objects.all().order_by('-id')
    paging = Paginator(border,2)
    
    arrPage=[]
    for i in range(paging.num_pages):
        arrPage.append(i+1)
    print(arrPage)
    context={
        'userAll':paging.page(page),
        'arrPage':arrPage
    }
    
    #userAll = Border.objects.values('id',
    #    '제목','작성자','내용','조회수').order_by('-id')
    #context = {"userAll":userAll}
    return render(request,'border/index.html',context)
def add(request):
    if request.method =='POST':
        table = Border()
        table.제목 = request.POST.get('title')
        table.내용 = request.POST.get('context')
        table.작성자 = request.POST.get('author')
        #table.작성일 = request.POST.get('cdate')
        #table.수정일 = request.POST.get('udate')
        table.작성일 = datetime.now()
        table.수정일 = datetime.now()
        table.조회수 = request.POST.get('vcount')
        table.save()
        return redirect('BD:index',1)
    else:
        return render(request,'border/add.html')


