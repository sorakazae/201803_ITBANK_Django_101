# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Border',
            fields=[
                ('id', models.AutoField(primary_key=True, serialize=False, auto_created=True, verbose_name='ID')),
                ('제목', models.CharField(max_length=225)),
                ('작성자', models.CharField(max_length=255)),
                ('내용', models.TextField()),
                ('작성일', models.DateTimeField()),
                ('수정일', models.DateTimeField()),
                ('조회수', models.IntegerField()),
            ],
        ),
    ]
