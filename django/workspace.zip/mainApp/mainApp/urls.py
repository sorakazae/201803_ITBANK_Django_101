from django.conf.urls import include, url
from django.contrib import admin
from mainApp import views
urlpatterns = [
    # Examples:
    # url(r'^$', 'mainApp.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),

    url(r'^admin/', include(admin.site.urls)),
    url(r'^phonebook/', include('phonebook.urls',namespace="PB")),
    url(r'^test/', views.test),
    url(r'^$', views.mainIndex, name='mainIndex'),
    url(r'^account/', include('django.contrib.auth.urls')),
    url(r'^script/', views.script),
    url(r'^account/register/', views.createAccount,name='createAccount'),
    url(r'^index/', views.index),
    url(r'^form/', views.form),
    url(r'^account/userInfo/([0-9]+)/', views.userInfo,name='userInfo'),
    url(r'^img/', views.img),
    url(r'^border/', include('border.urls',namespace="BD")),
    
]



















