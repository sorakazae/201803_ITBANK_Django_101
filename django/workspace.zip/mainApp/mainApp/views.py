from django.shortcuts import render, redirect

from django.contrib.auth.models import User

def userInfo(request,userId):
    userInfo = User.objects.get(id=userId)
    print('userInfo : ',userInfo)
    if request.method == 'GET':
        return render(request,'userInfo.html',{'userInfo':userInfo})
    else:
        user = request.user
        user.username = request.POST.get('username')
        user.last_name = request.POST.get('last_name')
        user.first_name = request.POST.get('first_name')
        user.email = request.POST.get('email')
        user.save()
        
        return redirect('userInfo.html',{'userInfo':userInfo})



def index(request):
    return render(request,'index.html')
def form(request):
    return render(request,'form.html')
def createAccount(request):
    print('User.objects.get(id=1) :',User.objects.get(id=1))
    print('User.objects.all() :',User.objects.all())
    print('User.objects.values("id","username") :',
          User.objects.values("id","username"))
    if request.method == 'GET':
        return render(request,'registration/createAccount.html')
    elif request.method == 'POST':
        User.objects.create_user(
            username=request.POST.get('name'),
            email=request.POST.get('email'),
            first_name=request.POST.get('first_name'),
            last_name=request.POST.get('last_name'),
            password=request.POST.get('pwd')
        )
        return redirect('login')
        
def script(request):
    return render(request,"script.html")
def mainIndex(request):
    '''
    print('로그인한 사용자 :', request.user.username)
    print('로그인한 사용자 id :', request.user.id)
    print('로그인 확인 : ',request.user.is_active)
    print('관리자인지 : ',request.user.is_superuser)
    print('마지막 로그인한 날짜 : ',request.user.last_login)
    print('이름 :',request.user.first_name)
    print('성 :',request.user.last_name)
    print('이메일 :',request.user.email)
    '''
    return render(request,'mainIndex.html')
def test(request):
    print("get 방식")
    print('userId :',request.GET.get("userId"))
    print('userPwd :',request.GET.get("userPwd"))
    print("post 방식")
    print('userId :',request.POST.get("userId"))
    print('userPwd :',request.POST.get("userPwd"))
    
    
    return render(request,'myhtml/test.html')
def img(request):
    return render(request,'img.html')




