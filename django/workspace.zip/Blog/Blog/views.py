from django.shortcuts import render
def blog(request,year):
    print(year,'년 blog 연결 입니다')
def blogName(request,name):
    print(name,'접속')
    print('%s접속'%name)
    print('{}접속'.format(name))
    return render(request,'myhtml/test.html')
def aaa(request):
    return render(request,'myhtml/board.html')






