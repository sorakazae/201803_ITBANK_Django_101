from django.conf.urls import include, url
from django.contrib import admin
from Blog import views
urlpatterns = [
    url(r'^admin/', include(admin.site.urls)),
    url(r'^blog/([0-9]{4})/', views.blog ),
    url(r'^blogname/([a-zA-Z]+)/', views.blogName ),
    url(r'^board/', views.aaa ),
    
]

