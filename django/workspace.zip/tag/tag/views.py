from django.shortcuts import render
def test(request):
    context = {
         "키":"키에의한 값 표현",
         "num_1":100 ,
         "flt_1":10.123 ,
         "str_1":"문자열 저장" ,
         "list_1":[10,20,"리스트"] ,
         "dic_1":{'a':'a저장','b':'b저장'},
         "순위":
         [
          [1,2,3,4,5],
          ['육','7','팔','구','10'],
          [11,12,13,14,15],
         ],
         "url":{
             '네이버':'https://www.naver.com/',
             '구글' : 'https://www.google.co.kr/',
             '다음' : 'https://www.daum.net/'
             }
    }
    return render(request,'myhtml/test.html',context)
def control(request):
    context = {
        "num_1":100 ,
        "flt_1":10.123 ,
        "순위":
         [
          [1,2,3,4,5],
          ['육','7','팔','구','10'],
          [11,12,13,14,15],
         ]
    }
    return render(request,'myhtml/control.html',context)
def worldcup(request):
    context = {
        'worldcup':
        [
         ['순위','국가','승점','승','무','패','득점','실점','골득실'],
         [1,{'이란':'http://www.naver.com/'},0,0,0,0,0,0,0],
         [2,{'대한민국':'http://www.naver.com/'},0,0,0,0,0,0,0],
         [3,{'시리아':'http://www.naver.com/'},0,0,0,0,0,0,0]
        ]
    }
    return render(request,'myhtml/worldcup.html',context)



















