from django.conf.urls import include, url
from django.contrib import admin
from tag import views
urlpatterns = [
    # Examples:
    # url(r'^$', 'tag.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),
    url(r'^admin/', include(admin.site.urls)),
    url(r'^test/', views.test),
    url(r'^control/', views.control),
    url(r'^worldcup/', views.worldcup),
]
