'''
Created on 2018. 3. 24.

@author: admin
'''
from django.conf.urls import url
from . import views

app_name = 'blog' #{% url 'blog:index' %}
urlpatterns = [
    #127.0.0.1:8000/blog/
    #클래스 기반의 뷰는 .as_view()함수를 호출해야함
    url(r'^$', views.index.as_view() , name='index'), 
    url(r'^detail/(?P<pk>\d+)/$',views.detail.as_view(),name='detail'),
    url(r'^posting/$',views.posting.as_view(),name='posting'),
    url(r'^updateposting/(?P<pk>\d+)/$', views.updatePosting.as_view() ,name='updateposting'),
    url(r'^comment/$',views.commentWrite, name='commentwrite'),
    url(r'^search/$',views.search.as_view(),name='search'),
]




